const Constants = {
    VAT: 1.17
}

let Globals = {
    allProducts: [],
    customer: null,
    cart: null
}

export {Constants, Globals};
